title: 【LOG4J】
date: '2019-08-14 17:49:09'
updated: '2019-08-14 17:49:09'
tags: [LOG4J]
permalink: /articles/2019/08/14/1565776149613.html
---
jar包

```
<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-core -->
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-core</artifactId>
    <version>2.11.2</version>
</dependency>

```

## 权限

```
off        最高权限，用于关闭所有的日志记录
fatal      指出每个严重错误事件将会导致应用程序的退出
error      指出虽然发生错误时间，但仍然不影响系统的继续运行
warm       表明会出现潜在的错误情形
info       一般和在粗粒度级别上，强调应用程序的运行全程
debug      一般用于细粒度级别上，对调试应用程序非常有帮助
all        最低等级，用于打开所有日志记录
```
