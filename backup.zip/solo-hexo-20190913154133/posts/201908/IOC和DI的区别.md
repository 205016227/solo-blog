title: 【IOC和DI的区别】
date: '2019-08-14 18:03:09'
updated: '2019-08-14 18:03:09'
tags: [Spring]
permalink: /articles/2019/08/14/1565776989160.html
---
## ioc和di是一个东西吗？有什么区别？

```
是一个东西

```

## ioc和di的区别

```
IOC控制反转
    IOC控制反转，是将对象控制反转到IOC容器当中
DI依赖注入
    从IOC容器中取出我们需要的对象放到我们自己的对象中
```
