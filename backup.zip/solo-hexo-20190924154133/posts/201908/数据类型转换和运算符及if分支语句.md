title: 【数据类型转换和运算符及if分支语句】
date: '2019-08-26 15:06:35'
updated: '2019-08-26 15:08:36'
tags: [java基础]
permalink: /articles/2019/08/26/1566803195791.html
---
# 一.数据类型转换
1. 按照取值范围从小到大排列:byte,short,char-->int-->long-->float-->double
    
2. 数据类型转换什么时候发生?
    
    等号左右两边的数据类型不一致时
## 自动类型转换
自动类型转换:
        取值范围大的数据类型 变量名 = 取值范围小的数据类型
```
代码演示:
 public class Demo01DataType {
    public static void main(String[] args) {
        /*
           等号右边的10默认类型是int型
           将int型的10赋值给了long型的变量l,符合取值范围小的数据类型赋值给取值范围大的数据类型
           发生了自动类型转换
         */
       long l = 10;

       double d = 10;
    }
}
```
## 强制类型转换
1.什么时候发生?
         取值范围小的数据类型 变量名 = 取值范围大的数据类型
2.解决:
         取值范围小的数据类型 变量名 =(取值范围小的数据类型) 取值范围大的数据类型
```
代码演示：
 public class Demo02DataType {
    public static void main(String[] args) {
        /*
           2.5默认类型是double,此代码是将double型的2.5赋值给了int型的变量i
           由于double取值范围大,int型的取值范围小,那么代码需要强制类型转换
         */
        //int i = 2.5;
        int i = (int)2.5;

        int i1 = (int)100L;

        int j = 10;
        double k = 20.5;

        /*
           一个小类型的和一个大类型的做运算,小类型的会自动提升为大类型的
         */
        int sum = (int)(j+k);
    }
}
注意事项：
  1.我们不要随便写强制类型转换(除非是硬性需要),会出现精度损失,数据溢出
  2.byte,short,char参与运算的时候,会首先被提升为int型(char类型提升为int之后,会去一个码表中查询该字     符对应的int值)
```
# 二.运算符
## 1.算数运算符
 基本算数运算符:
     +:加法,和字符串拼接(任何类型遇到字符串都会变成字符串)
     -
     *
     /:取的是整数部分
     %(模):取余数
     
     
   自增和自减:变化1
     1.格式:
	```
	变量++   ++变量     变量--     --变量
	```	
     2.单独使用:
  	```
	自己独立成为一句
	i++;
	```
注意:
	```
	符号在前或者在后没有区别
	```
 混合使用:和输出语句,赋值语句混合使用了
注意:
	```
	符号在前(先运算,再使用-->先运算,运算之后,再用运算后的值)
	```
	```
	符号在后(先使用,再运算-->先使用原值,使用完了以后,再运算)
	```
## 2.关系运算符
比较运算符:结果肯定是boolean类型
      `==  :判断两个数是否相等,相等返回true,不相等false`
      `>:判断前面的是否比后面的大,大的话true,否则false`
      `<:判断前面的是否比后面的小,小的话true,否则false`
      `>=:判断前面的是否比后面的大或者相等,如果大或者相等返回true,否则false`
      `<=:判断前面的是否比后面的小或者相等,如果小或者相等返回true,否则false`
      `!=:判断两个数是否不等,如果不等返回true,如果相等返回false`

```
代码演示:
   public class Demo01BiJiao {
    public static void main(String[] args) {
        int i = 20;
        int j = 20;

        boolean result01 = i==j;
        System.out.println(result01);

        System.out.println(i<j);
        System.out.println(i!=j);
        System.out.println(i>=j);
        System.out.println(1>=5);
    }
}

```
## 3.赋值运算符

赋值运算符:

```
     基本:=
        int i = 10
```
复合:
```
         +=
            int i =10;
            i+=2-->i = i+2
         -=
            i-=2-->i = i-2
         *=
            i*=2-->i = i*2
         /=
            i/=2-->i = i/2
         %=
            i%=3-->i = i%3
     byte,short,char参与运算的时候会被提升为int型,但是遇到复合赋值运算符,不用强转
```
```
 代码演示:
    public class Demo01FuZhi {
    public static void main(String[] args) {
        int i = 10;
        /*i+=2;//i = i+2
        System.out.println(i);
        */
        //System.out.println(i/=3);
        System.out.println(i%=3);


        byte b = 10;
        b+=20;//b = b+20
        System.out.println(b);
    }
}
```
## 4.逻辑运算符
逻辑运算符:boolean表达式 逻辑运算符 boolean表达式
```
      &&:与
         有假则假:符号前后有一个boolean表达式是false,那么整体就是false

         特点:短路效果(符号前面为false,符号后面不判断了)

      ||:或
         有真则真:符号前后有一个boolean表达式是true,那么整体就是true

         特点:短路效果:如果符号前为true,后面不看
      !:非
         取反
      ^:异或(不用)
         a和b结果不同为true，相同为false
   扩展:判断一个变量是否是1-100之间的数
        1<=x<=100  错误写法

        x>=1 && x<=100  正确写法

        1<=x && 100>=x   正确写法
```
```
代码演示:
  public class Demo01LuoJi {
    public static void main(String[] args) {
       int i = 10;
       int j = 20;
       int k = 20;
       boolean result = (i>k)&&(i>j);
       System.out.println(result);

       System.out.println((i<k)||(i>j));
       System.out.println(!((i<k)||(i>j)));

       System.out.println((i<k)^(i<j));

    }
}

```
## 5.三元运算符
 格式:boolean表达式?表达式1:表达式2
 ```
 执行流程:
          1.走boolean表达式,如果是true,走?后面的表达式1
          2.否则走:后面的表达式2
```
```
 代码演示:
    public class Demo01SuanYuan {
    public static void main(String[] args) {
        /*
          需求:定义一个变量,当分数,判断这个分数是否及格
         */

        int score = 60;
        String result = (score>=60)?"及格":"不及格";
        System.out.println(result);
    }
}
```
# 三.Scanner:键盘录入
```
 Scanner:
      1.概述:类  Java自带的类
      2.数据类型:引用数据类型
      3.作用:可以通过键盘录入的形式将数据放到代码中
      4.用法:
             导包:idea自动导包-->alt+回车
             创建对象:Scanner 变量名 = new Scanner(System.in)
             调用方法:变量名.方法名()

                     next():录入字符串
                     nextInt():录入整数
                     nextDouble():录入小数

                     nextxxx()
                     
 代码演示:
    public class Demo01Scanner {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请你输入用户名:");
        String s = sc.next();
        System.out.println(s);
        System.out.println("请你输入密码:");
        String p = sc.next();
        System.out.println(p);

        System.out.println("登录成功");
    }
}
```
# 四.分支语句
### if语句:
```
格式:
     if(boolean表达式){
       执行语句
     }

    执行流程:
       1.走if后面的boolean表达式
       2.如果返回true,那么就走if后面大括号中的执行语句

   使用场景:
      有一种情况的,if
      
代码演示:
   public class Demo01If {
    public static void main(String[] args) {
        /*
           定义一个变量,判断是否大于10
         */

        int i = 10;
        if (i>10) {
            System.out.println("大于10");
        }

        System.out.println("我要执行");
    }
}
```
### if..else语句:
```
格式:
      if(boolean表达式){
         执行语句1
      }else{
         执行语句2
      }

    执行流程:
       1.走if后面的boolean表达式
       2.如果返回true,那么就走if后面大括号中的执行语句1
       3.否则,走else后面大括号中的执行语句2
    使用场景:
        2种情况
--------------------------------------------------------------------------------        
    代码演示:
       /*
         练习:
         键盘录入一个数,判断奇偶

    步骤:
       1.创建Scanner:Scanner sc = new Scanner(System.in)
       2.调用nextInt()录入一个整数
       3.利用if语句  %2==0,如果等等于0,输出是偶数
       4.否则就是奇数
 */
public class Demo03IfElseTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if (a%2==0){
            System.out.println("是偶数");
        }else{
            System.out.println("是奇数");
        }
    }
}
```
### else if语句:
```
格式:
      if(boolean表达式){
        执行语句1
      }else if(boolean表达式){
        执行语句2
      }else if(boolean表达式){
        执行语句3
      }....{

      }else{
        执行语句n
      }

执行流程:
       1.走if后面boolean表达式,如果是true,就走if后面的大括号中的执行语句1
       2.如果是false,就走else if后面的boolean表达式,如果是true,就执行对应的执行语句2
       3.如果还是false,那么就继续走下一个else if 接着判断
       4.如果以上所有的判断都不成立,那么执行else

 使用场景:
       2种情况以上的判断
       
 代码演示:
    练习:键盘录入一个分数,划分等级,获取对应的奖励
      95~100		山地自行车一辆
      90~94		游乐场玩一次
      80~89		变形金刚玩具一个
      80以下		胖揍一顿
      
  public class Demo04ElseIf {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.println("请你输入一个分数:");
       int score = sc.nextInt();

       if (score>=95 && score<=100){
           System.out.println("奖励日本女演员一个!");
       }else if(score>=90 && score<=94){
           System.out.println("奖励日本男演员一个!");
       }else if(score>=80 && score<=89){
           System.out.println("奖励日本小电影网站一个!");
       }else if(score>100 || score<0){
           System.out.println("数据错误");
       }else{
           System.out.println("弄死");
       }
    }
}
```
