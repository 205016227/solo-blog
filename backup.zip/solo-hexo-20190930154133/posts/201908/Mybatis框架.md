title: 【Mybatis框架】
date: '2019-08-14 17:52:13'
updated: '2019-08-14 18:00:20'
tags: [Mybatis]
permalink: /articles/2019/08/14/1565776333651.html
---
官方文档[http://www.mybatis.org/mybatis-3/zh/getting-started.html](http://www.mybatis.org/mybatis-3/zh/getting-started.html)  
Mybatis是一个优秀的开源的持久层框架，它的底层封装的是JDBC

### Mybatis的入门

1.引入依赖  
MySql和MyBatis

```
<!--mysql-->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>5.1.26</version>
</dependency>
<!-- mybatis -->
<dependency>
    <groupId>org.mybatis</groupId>
    <artifactId>mybatis</artifactId>
    <version>3.5.1</version>
</dependency>

```

2.编写核心配置文件SqlMapConfig.xml(数据库的信息，映射文件)

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <environments default="development">
        <environment id="development">
            <transactionManager type="JDBC" />
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver" />
                <property name="url" value="jdbc:mysql://localhost:3306/itcast350?characterEncoding=utf8" />
                <property name="username" value="root" />
                <property name="password" value="root" />
            </dataSource>
        </environment>
    </environments>
    <mappers>
        <mapper resource="mapper/UserMapper.xml"></mapper>
    </mappers>
</configuration>

```

3.映射文件：提供SQL语句

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="User">
    <select id="findAll" resultType="cn.itcast.domain.User">
        select * from User
    </select>
</mapper>

```

4.实体类

```
public class User {
    private  int id;
    private String username;
    private String gender;
    private Date birthday;
    private String address;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", gender='" + gender + '\'' +
                ", birthday=" + birthday +
                ", address='" + address + '\'' +
                '}';
    }
}

```

5.测试类

```
public class Test {
    public static void main(String[] args) {
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sessionFactory = builder.build(Test.class.getClassLoader().getResourceAsStream("config/SqlMapConfig.xml"));
        SqlSession sqlSession = sessionFactory.openSession();
        List<User> users = sqlSession.selectList("User.findAll");
        for (User user : users) {
            System.out.println(user);
        }
    }
}

```

```
 SqlSessionFactoryBuilder构建SqlSessionFactory
 SqlSessionFactory创建SqlSession对象
 SqlSession访问selectList，selectOne...方法
 释放资源
```
