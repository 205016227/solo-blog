title: BCrypt密码加密
date: '2019-08-17 23:54:11'
updated: '2019-08-17 23:54:11'
tags: [加密算法]
permalink: /articles/2019/08/17/1566057251390.html
---
# 1 BCrypt快速入门
在用户模块，对于用户密码的保护，通常都会进行加密。我们通常对密码进行加密，然后存放在数据库中，在用户进行登录的时候，将其输入的密码进行加密然后与数据库中存放的密文进行比较，以验证用户密码是否正确。 目前，MD5和BCrypt比较流行。相对来说，BCrypt比MD5更安全。
[点击进入BCrypt 官网](http://www.mindrot.org/projects/jBCrypt/)
（1）我们从官网下载源码
（2）新建工程，将源码类BCrypt拷贝到工程
（3）新建测试类，main方法中编写代码，实现对密码的加密
```
String gensalt = BCrypt.gensalt();//这个是盐  29个字符，随机生成
System.out.println(gensalt);
String password = BCrypt.hashpw("123456", gensalt);  //根据盐对密码进行加密
System.out.println(password);//加密后的字符串前29位就是盐
```
（4）新建测试类，main方法中编写代码，实现对密码的校验。BCrypt不支持反运算，只支持密码校验。
```
boolean checkpw = BCrypt.checkpw("123456",     "$2a$10$61ogZY7EXsMDWeVGQpDq3OBF1.phaUu7.xrwLyWFTOu8woE08zMIW");
System.out.println(checkpw);
```


