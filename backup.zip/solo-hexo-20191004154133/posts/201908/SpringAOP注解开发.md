title: 【Spring AOP注解开发】
date: '2019-08-14 18:02:14'
updated: '2019-08-14 18:02:14'
tags: [Spring]
permalink: /articles/2019/08/14/1565776934492.html
---
## 定义配置类

```
/**
 * Configuration   配置spring容器   相当于把该类作为spring的xml配置文件中的<beans>
 * ComponentScan   扫描包路径注解扫描       从中找出标识了需要装配的类自动装配到spring的bean容器中
 * EnableAspectJAutoProxy   开启AspectJ 自动代理模式 
 */
@Configuration
@ComponentScan("cn.itcast")
@EnableAspectJAutoProxy
public class Config {
}

```

## 定义增强类

```
/**
 * @Aspect  把当前类标识为一个切面供容器读取
 */
@Component("advisor")
@Aspect
public class LogAdvisor {
    /**
     *
     * Pointcut   植入
     *
     *定义execution表达式
     * 第一个*   返回值类型
     * cn.itcast.service..*.*(..)
     *      ..    service下某个包下
     *      *.*   某个类.某个方法
     *      (..)   参数列表
     */
    @Pointcut("execution(* cn.itcast.service..*.*(..))")
    public void xxx(){

    }

    /**
     * 在方法执行前追加   execution表达式
     */
    //@Before("execution(* cn.itcast.service..*.*(..))")
    public void before(){
        System.out.println("方法执行之前");
    }

    /**
     * 在方法之后追加逻辑   引用execution表达式
     */
    //@After("xxx()")
    public void after(){
        System.out.println("方法之后");

    }

    /**
     * 方法异常时
     */
    //@AfterThrowing("xxx()")
    public void throwing(){
        System.out.println("异常");
    }

    /**
     * 最终   都会执行
     */
    //@AfterReturning("xxx()")
    public void returning(){
        System.out.println("finally");
    }

    /**
     *  joinPoint 代表原方法本身
     * @param joinPoint
     * @return
     *
     * 环绕增强
     * tcf模型        try-catch-finally
     *      包含：方法前   方法后     异常     最终(finally)
     */
    @Around("xxx()")
    public Object around(ProceedingJoinPoint joinPoint){
        try {
            System.out.println("方法之前");
            Object proceed = joinPoint.proceed();
            System.out.println("方法之后");
            return proceed;

        }catch (Throwable e){
            System.out.println("方法异常");
            throw new RuntimeException(e);
        }finally {
            System.out.println("最终");
        }
    }
}
```
