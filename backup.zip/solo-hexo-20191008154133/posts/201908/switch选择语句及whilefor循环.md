title: 【switch选择语句及while、for循环】
date: '2019-08-27 15:53:04'
updated: '2019-08-27 15:53:04'
tags: [java基础]
permalink: /articles/2019/08/27/1566892384282.html
---
# 一.选择语句
```
1.选择语句:switch
    格式:
       switch(表达式){
          case 常量值1:
          执行语句1;
          break;

          case 常量值2:
          执行语句2;
          break;

          case 常量值3:
          执行语句3;
          break;

          case 常量值4:
          执行语句4;
          break;
          .....

          default:
          执行语句n;
          break;
       }

    2.执行流程:
          1.拿着我们所填的表达式去和下面每一个case后面的常量值去做匹配,匹配上谁,就走
            对应的执行语句
          2.如果以上所有的case都没有匹配上,直接走default对应的执行语句

    3.注意:case后面的常量值的类型要和我们所填写的表达式的类型一致

        break是结束switch语句结构的
```
```
代码演示:
    public class Demo01Switch {
    public static void main(String[] args) {
        int i = 5;
        switch (i) {
            case 1:
                System.out.println("涛哥最帅!");
                break;
            case 2:
                System.out.println("波多小姐最美");
                break;
            case 3:
                System.out.println("大桥也很美!");
                break;
            case 4:
                System.out.println("柳岩也很美!");
                break;
            default:
                System.out.println("他们都挺喜欢涛哥!");
                break;
        }
    }
    ========================================================
 练习:
    public static void main(String[] args) {
    //定义月份变量，判断季节
    int month = 6;
    //switch语句实现选择
    switch(month) {
        case 1:
            System.out.println("冬季");
            break;
        case 2:
            System.out.println("冬季");
            break;
        case 3:
            System.out.println("春季");
            break;
        case 4:
            System.out.println("春季");
            break;
        case 5:
            System.out.println("春季");
            break;
        case 6:
            System.out.println("夏季");
            break;
        case 7:
            System.out.println("夏季");
            break;
        case 8:
            System.out.println("夏季");
            break;
        case 9:
            System.out.println("秋季");
            break;
        case 10:
            System.out.println("秋季");
            break;
        case 11:
            System.out.println("秋季");
            break;
        case 12:
            System.out.println("冬季");
            break;
        default:
            System.out.println("你输入的月份数字有误");
            break;
    }
}
}


4.没有break会出现case的穿透性
    如果没有break就一直往下穿透执行,直到遇到break或者程序结束了为止
  代码演示:
    public class Demo03Case {
    public static void main(String[] args) {
        int i = 3;
        switch (i) {
            case 1:
                System.out.println("涛哥最帅!");

            case 2:
                System.out.println("波多小姐最美");

            case 3:
                System.out.println("大桥也很美!");

            case 4:
                System.out.println("柳岩也很美!");
                break;
            default:
                System.out.println("他们都挺喜欢涛哥!");

        }
    }
}
```

# 二.for循环
```
 循环之for循环

      1.格式:
         for(初始化变量;比较;变量变值){
            循环体
         }

      2.执行流程:
          1.先初始化变量
          2.拿着这个变量去比较
          3.如果比较成功,返回true,那么直接走循环体
          4.变量的值变化(步进表达式)
          5.接着比较,比较返回true,接着走循环体
          6.接着步进表达式
          7.接着比较,直到比较返回false,那么整个循环结束了
          
      3.代码演示:
         for(int i = 1;i<=10;i++){
            System.out.println("我爱Java");
         }
         或者:
         for(int i = 0;i<10;i++){
            System.out.println("我爱Java");
         }
```

# 三.while循环
```
1.格式:
       初始化变量;
       while(比较){
         循环体;
         步进表达式;
       }

2.执行流程:
         1.初始化变量
         2.比较
         3.如果比较返回true,进入循环体
         4.步进表达式
         5.接着比较,直到比较返回false,while循环结束了!
3.代码演示:
    public class Demo01_While {
    public static void main(String[] args) {
        /*
         循环10次,性感涛哥,在线发牌
         */
        int i = 0;
        while(i<10){
            System.out.println("性感涛哥,在线发牌"+i);
            i++;
        }
    }
}
```

# 四.死循环
```
/*
  死循环:一直循环

  条件:一直为true

 */
public class DieFor {
    public static void main(String[] args) {
        /*for (int i = 0;i<10;){
            System.out.println("岳不群自宫了~");
        }*/

        while(true){
            System.out.println("孙悟空是最纯洁的猴");
        }
    }
}
```
# 五.嵌套for循环
```
1.概述:for中有for
2.执行流程:
    先执行外层for循环,再执行内层for循环,内存for循环就一直循环,直到内层for循环结束,外层for循环进行下一次     循环.... 直到外层for循环结束了,那么整个所有的循环都结束了   
    
3.代码演示:
    public class ForAndFor {
    public static void main(String[] args) {
        for (int fen = 0; fen < 60; fen++) {
            for (int miao = 0;miao<60;miao++){
                System.out.println(fen+"分"+miao+"秒");
            }
        }

    }
}
```
