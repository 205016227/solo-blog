title: 【MyBatis的执行流程（自定义Mybatis框架）】
date: '2019-08-14 17:58:28'
updated: '2019-08-14 18:00:08'
tags: [Mybatis]
permalink: /articles/2019/08/14/1565776708387.html
---
SqlSessionFactoryBuilder构造者类，用来创建工厂  
工厂来创建一个个SqlSession  
SqlSession用来执行业务

## MyBatis底层原理：

从JDBC往上一层一层的封装，从我们写出来的JDBC代码中发现不足，把不足之处或者共性之处慢慢的往上抽取，最终形成了MyBatis

---

```

CREATE TABLE `user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(32) NOT NULL COMMENT '用户名称',
  `gender` CHAR(1) DEFAULT NULL COMMENT '性别',
  `birthday` DATE DEFAULT NULL COMMENT '生日',
  `address` VARCHAR(256) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*添加用户*/
INSERT INTO `user` VALUES ('1', '张三', '1', '2018-07-10', '北京');
INSERT INTO `user` VALUES ('2', '李四', '1', '2018-07-10', '上海');
INSERT INTO `user` VALUES ('3', '王五', '1', '2018-07-10', '广州');
INSERT INTO `user` VALUES ('4', '赵六', '1', '2018-07-10', '深圳');

```

# 使用User表实现自定义MyBatis框架

## 准备工作

1、把数据库配置文件（SqlMapConfig.xml）放到resources资源肯路径下

```
<?xml version="1.0" encoding="UTF-8" ?>   
<configuration>   
   <environments default="development">   
      <environment id="development">   
        <transactionManager type="JDBC" ></transactionManager>   
        <dataSource type="POOLED">   
          <property name="driver" value="com.mysql.jdbc.Driver" ></property>
          <property name="url" value="jdbc:mysql://localhost:3306/mybatis?characterEncoding=utf8" ></property>
          <property name="username" value="root" ></property>
          <property name="password" value="root" ></property>
        </dataSource>   
     </environment>   
  </environments>
    <mappers>
        <mapper resource="UserMapper.xml"></mapper>
    </mappers>
</configuration>

```

2、导入mysql驱动包、解析xml和的(jar)

```
<!-- mysql驱动包 -->
<dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>5.1.26</version>
</dependency>
<!-- 解析xml的包dom4j -->
<dependency>
    <groupId>dom4j</groupId>
    <artifactId>dom4j</artifactId>
    <version>1.6.1</version>
</dependency>
<!-- XPath语法的包jaxen -->
<dependency>
    <groupId>jaxen</groupId>
    <artifactId>jaxen</artifactId>
    <version>1.2.0</version>
</dependency>

```

3、导入连接池包（这里使用的是HikariCP连接池）

```
<!-- 连接池包HikariCP -->
<dependency>
    <groupId>com.zaxxer</groupId>
    <artifactId>HikariCP</artifactId>
    <version>3.3.1</version>
</dependency>

```

4、准备sql配置文件UserMapper.xml

```
<?xml version="1.0" encoding="utf-8" ?>
<mapper namespace="user">
    <select id="findAll" resultType="org.custom_mybatis.domain.User">
        select * from user
    </select>
</mapper>

```

## 代码实现

1、创建User实体类

```
public class User {
    private int id;
    private String username;
    private String gender;
    private Date birthday;
    private String address;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", gender='" + gender + '\'' +
                ", birthday=" + birthday +
                ", address='" + address + '\'' +
                '}';
    }
}

```

2、创建SqlMap类，在解析出Sql配置文件，查询拿到结果集，遍历时我们需要知道时什么类型  
此类用于存储sql语句和所对应的对象

```
public class SqlMap {
    //Sql语句
    private String sql;
    //什么类型的对象
    private Class clazz;

    public SqlMap() {
    }

    public SqlMap(String sql, Class clazz) {
        this.sql = sql;
        this.clazz = clazz;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public Class getClazz() {
        return clazz;
    }

    public void setClazz(Class clazz) {
        this.clazz = clazz;
    }
}

```

3、创建Configuration类用来存储，从配置文件中解析出来的东西

```
public class Configuration {
    /**
     * 存储的是解析好的数据库链接池
     */
    private DataSource dataSource;
    /**
     * 放着是解析好的 配置文件中的SQl语句     放到Map集合中(容易获取)
     * 键：sql配置文件中的命名空间的值  +   mapper根标签下的标签的id属性值
     * 值：sql语句
     *
     * {
     *     "user.findAll":{
     *         sql:"select * from user",
     *         clazz:"xxxclass"
     *     },
     *    "product.findAll":{
     *         sql:"select * from product",
     *         clazz:"xxxclass"
     *    },
     *     ...
     * }
     */
    private Map<String,SqlMap> sqlMaps = new HashMap<>();

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, SqlMap> getSqlMaps() {
        return sqlMaps;
    }

    public void setSqlMaps(Map<String, SqlMap> sqlMaps) {
        this.sqlMaps = sqlMaps;
    }
}

```

4、创建建造者类SqlSessionFactoryBuilder用于创建工厂（Factory）  
在此类中解析了数据库配置文件和SQL配置文件

```
public class SqlSessionFactoryBuilder {

    //默认在资源根路径(resources)找配置文件(SqlMapConfig.xml),找不到报错
    public SqlSessionFactory build(){
        //是用类加载器拿到配置文件流
        InputStream inputStream = SqlSessionFactoryBuilder.class.getClassLoader().getResourceAsStream("SqlMapConfig.xml");



        return build(inputStream);
    }




    //传递配置文件的路径
    public SqlSessionFactory build(String path){
        InputStream inputStream = SqlSessionFactoryBuilder.class.getClassLoader().getResourceAsStream(path);




        return build(inputStream);
    }




    //传递配置文件的流
    public SqlSessionFactory build(InputStream inputStream){
        Configuration configuration = new Configuration();

        //解析配置文件
        SAXReader saxReader = new SAXReader();
        try {
            //读取配置文件，得到document对象
            Document document = saxReader.read(inputStream);
            //解析数据库连接池
            DataSource dataSource = loadDataSource(document);
            configuration.setDataSource(dataSource);

            //解析sql语句配置文件
            Map<String,SqlMap> sqlMaps = loadSqlMaps(document);
            configuration.setSqlMaps(sqlMaps);


        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return new SqlSessionFactory(configuration);
    }

    private Map<String,SqlMap> loadSqlMaps(Document document) {
        Map<String,SqlMap> map = new HashMap<>();
        /**
         * 获取SqlMapConfig.xml中的mapper标签
         */
        List<Element> list = document.selectNodes("//mapper");
        for (Element element : list) {
            //找到SQL语句配置文件的位置
            String path = element.attributeValue("resource");
            //解析一个个SQL配置文件
            loadSqlMap(path,map);
        }
        return map;
    }

    private void loadSqlMap(String path,Map<String,SqlMap> map) {
        SAXReader saxReader = new SAXReader();
        try {
            /**
             * 拿到SQL配置文件的元素对象
             */
            Document document = saxReader.read(SqlSessionFactoryBuilder.class.getClassLoader().getResourceAsStream(path));
            //拿到SQL配置文件的命名空间
            String namespace = document.getRootElement().attributeValue("namespace");
            /**
             * 得到SQL配置文件中所有的select标签
             */
            List<Element> list = document.selectNodes("//select");
            for (Element element : list) {
                //拿到select标签的id属性值
                String id = element.attributeValue("id");

                //得到select标签体中的sql语句
                String sql = element.getTextTrim();
                //拿到select标签的resultType属性值
                //org.custom_mybatis.domain.User
                String resultType = element.attributeValue("resultType");
                String key = namespace+"."+id;
                Class<?> aClass = Class.forName(resultType);
                map.put(key,new SqlMap(sql,aClass));
            }

        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 准备一个DataSource  连接池
     * @param document
     * @return
     */
    private DataSource loadDataSource(Document document) {

        /**
         *    //:表示不管在文档的那个位置    只要是property我就拿\
         *    Element元素对象
         */
        List<Element> list = document.selectNodes("//property");


        HikariConfig config = new HikariConfig();


        for (Element element : list) {
            //拿到property的name属性的值
            String nameValue = element.attributeValue("name");
            if("driver".equals(nameValue)){
                //拿到property的value属性的值
                String valueValue = element.attributeValue("value");
                config.setDriverClassName(valueValue);
            }
            if("url".equals(nameValue)){
                //拿到property的value属性的值
                String valueValue = element.attributeValue("value");
                config.setJdbcUrl(valueValue);
            }
            if("username".equals(nameValue)){
                //拿到property的value属性的值
                String valueValue = element.attributeValue("value");
                config.setUsername(valueValue);
            }
            if("password".equals(nameValue)){
                //拿到property的value属性的值
                String valueValue = element.attributeValue("value");
                config.setPassword(valueValue);
            }
        }
        HikariDataSource hikariDataSource = new HikariDataSource(config);
        return hikariDataSource;
    }


}

```

5、创建工厂类  
此类用来帮我们创建一个个的SqlSession

```
public class SqlSessionFactory {

    private Configuration configuration;

    public SqlSessionFactory(Configuration configuration) {
        this.configuration = configuration;
    }

    public SqlSession openSession(){
        DefaultSqlSession defaultSqlSession = new DefaultSqlSession();



        defaultSqlSession.setConfiguration(configuration);
        return defaultSqlSession;
    }
}

```

6、使用ReflectorUtil工具类  
此工具类根据反射获取的对象调用此对象的set和get方法

```
public class ReflectorUtil {
    private static Map<Class,BeanMethodInfo> cache=new HashMap<>();


    private static BeanMethodInfo getBeanMethodInfo(Object o){
        Class<?> oClass = o.getClass();
        BeanMethodInfo beanMethodInfo = cache.get(oClass);
        if (beanMethodInfo==null){
            beanMethodInfo = new BeanMethodInfo(o.getClass());
            cache.put(oClass,beanMethodInfo);
        }
        return beanMethodInfo;

    }
    public static void set(Object o,String propertyName,Object propertyValue){
        BeanMethodInfo beanMethodInfo = getBeanMethodInfo(o);
        Method method = beanMethodInfo.setterMethod(propertyName);
        try {
            method.invoke(o,propertyValue);
        } catch (Exception e) {
            throw new RuntimeException("set--"+propertyName+"--property failed!",e);
        }
    }
    public static Object get(Object o,String propertyName){
        BeanMethodInfo beanMethodInfo = getBeanMethodInfo(o);
        Method method = beanMethodInfo.getterMethod(propertyName);
        try {
            return method.invoke(o);
        } catch (Exception e) {
            throw new RuntimeException("get--"+propertyName+"--property failed!",e);
        }
    }

    private static final class BeanMethodInfo{

        private Class clazz;
        private Map<String,Method> setterMethods=new HashMap<>();
        private Map<String,Method> getterMethods=new HashMap<>();

        public BeanMethodInfo(Class clazz) {
            this.clazz = clazz;
            addGetterMethods();
            addSetterMethods();
        }


        public Method setterMethod(String property){
            return setterMethods.get(property);
        }
        public Method getterMethod(String property){
            return getterMethods.get(property);
        }
        private  String methodToProperty(String name) {
            if(name.startsWith("is")) {
                name = name.substring(2);
            } else {
                if(!name.startsWith("get") && !name.startsWith("set")) {
                    throw new RuntimeException("Error parsing property name \'" + name + "\'.  Didn\'t start with \'is\', \'get\' or \'set\'.");
                }

                name = name.substring(3);
            }

            if(name.length() == 1 || name.length() > 1 && !Character.isUpperCase(name.charAt(1))) {
                name = name.substring(0, 1).toLowerCase() + name.substring(1);
            }

            return name;
        }
        private void addSetterMethods(){
            Method[] methods = clazz.getMethods();
            int len = methods.length;

            for(int i = 0; i < len; i++) {
                Method method = methods[i];
                String name = method.getName();
                if(name.startsWith("set") && name.length() > 3 && method.getParameterTypes().length == 1) {
                    String property = methodToProperty(name);
                    setterMethods.put(property,method);
                }
            }

        }
        private void addGetterMethods(){
            Method[] methods = clazz.getMethods();
            int len = methods.length;

            for(int i = 0; i < len; i++) {
                Method method = methods[i];
                String name = method.getName();
                if(name.startsWith("get") && name.length() > 3 || name.startsWith("is") && name.length() > 2) {
                    String property = methodToProperty(name);
                    getterMethods.put(property,method);
                }
            }

        }
    }
}

```

7、创建SqlSession接口和实现类DefaultSqlSession  
用到了面向接口编程：已扩展，当需求改变时只需要编写该业务的实现类，只需要更改配置文件中的实现类就可以了  
用于：帮助我们完成一次数据库业务操作

SqlSession接口

```
public interface SqlSession {
    /**
     * 调用我这个方法  帮助查询 你想要某个数据库表的数据 并且不需要给我连接对象 不用告诉怎么封装
     * 我自己都做了...
     * @param <A>
     * @return
     */
    <A>List<A> findAll(String statement);

}

```

实现类DefaultSqlSession

```
public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;

    public Configuration getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }

    /**
     * 传过来 statement = "user.findAll"
     * @param statement
     * @param <E>
     * @return
     */
    @Override
    public <E> List<E> findAll(String statement) {

        try {
            //数据库连接池   使用连接池方案
            Connection connection = configuration.getDataSource().getConnection();
            //有关sql语句
            SqlMap sqlMap = configuration.getSqlMaps().get(statement);
            PreparedStatement pstmt = connection.prepareStatement(sqlMap.getSql());
            ResultSet rs = pstmt.executeQuery();
            //封装结果集
            //获取你想要封装的类型
            Class clazz = sqlMap.getClazz();
            List list = handleResult(rs,clazz);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }/*finally {
            connection.close();关闭资源（不写）
            SqlSession代表业务操作的会话，有可能业务还没有操作完，需要继续使用该链接去执行一些其他的东西，应该由service调用方法时才决定什么时候关闭
        }*/
    }

    private List handleResult(ResultSet rs, Class clazz) throws SQLException, IllegalAccessException, InstantiationException {
        List list = new ArrayList();
        /**
         * ResultSet对象中有一个方法getMeteData()用来操作数据库元信息的操作，返回的是ResultSetMeteData对象
         *
         * 例：ResultSetMetaData metaData = rs.getMetaData();
         *          int countColumn metaData.getColumnCount();   查出来的数据一共有多少列
         *          遍历每一列
         *          for(int i = 1;i<countColumn;i++){
         *              String columnName = metaData.getColumnName(i);   每一列的名字
         *              String columnTypeName = metaData.getColumnTypeName(i);   每列的类型名
         *              String columnClassName = metaData.getColumnClassName(i);   列所对应的java类型
         *          }
         *
         */
        ResultSetMetaData metaData = rs.getMetaData();
        int countColumn =  metaData.getColumnCount();
        /**
         * 存储的是查询出来的所有的列名
         */
        List<String> columnNames = new ArrayList();
        for(int i = 1;i<=countColumn;i++){
            String columnName = metaData.getColumnName(i);
            columnNames.add(columnName);
        }
        //遍历结果集 将结果集的数据封装到需要类型的对象中
        while (rs.next()){

            //取出该行的数据

            //反射创建一个对象
            Object o = clazz.newInstance();

            //取出每列列名对应的值
            for (String columnName : columnNames) {
                Object columnvalue = rs.getObject(columnName);
                //把值赋值给对象对应的属性当中
                //调用对象中的set  get方法    使用工具类ReflectorUtil
                ReflectorUtil.set(o,columnName,columnvalue);
            }
            //把对象存储到list集合中
            list.add(o);


        }
        //再把对象添加到集合中
        return list;
    }
}

```

8、测试类

```
public class AppTest {

    @Test
    public void findAllTest() {
        //创建建造者对象
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = builder.build();
        //只要要对象  多次要对象的时候 就整一个工厂
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> all = sqlSession.findAll("user"+"."+"findAll");
        System.out.println(all);
    }


}
```
