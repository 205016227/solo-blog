title: 【Spring AOP】
date: '2019-08-14 17:59:34'
updated: '2019-08-14 17:59:34'
tags: [Spring]
permalink: /articles/2019/08/14/1565776774760.html
---
## 需要得jar包

```
<!-- 事务的支持包 -->
<dependency>
     <groupId>org.springframework</groupId>
     <artifactId>spring-aop</artifactId>
     <version>5.1.8.RELEASE</version>
</dependency>
<!-- 织入逻辑 -->
<dependency>
    <groupId>org.aspectj</groupId>
    <artifactId>aspectjweaver</artifactId>
    <version>1.9.4</version>
</dependency>

```

## 用来做增强得类

```
@Component("advisor")
public class LogAdvisor {
    public void before(){
        System.out.println("方法执行之前");
    }
    public void after(){
        System.out.println("方法之后");

    }

    public void throwing(){
        System.out.println("异常");
    }

    public void returning(){
        System.out.println("finally");
    }
    /**
     *  joinPoint 代表原方法本身
     * @param joinPoint
     * @return
     */
    public Object around(ProceedingJoinPoint joinPoint){
        try {
            System.out.println("方法之前");
            Object proceed = joinPoint.proceed();
            System.out.println("方法之后");
            return proceed;

        }catch (Throwable e){
            System.out.println("方法异常");
            throw new RuntimeException(e);
        }finally {
            System.out.println("最终");
        }
    }
}

```

```
<!-- 配置aop -->
<aop:config>
    <!-- 用来做增强得对象 -->
    <aop:aspect id="xxx" ref="advisor">
            <!-- 把execution抽取出来，其他得配置引用即可 -->
            <aop:pointcut id="zzz" expression="execution(* *.*.*..*.*(..))"></aop:pointcut>

            <!--往原本对象得方法之前加逻辑 
                method="增强对象中得方法"
                execution要加强得xx方法
            -->
            <aop:before method="beforex" expression="execution( * com.itheima.service..*.*(..))"></aop:before>
            <!-- 往原本对象得方法之后加逻辑
                pointcut-ref="引用抽取得execution配置"
            -->
            <aop:after method="after" pointcut-ref="zzz"></aop:after>
            <!--原本对象方法异常时
            -->
            <aop:after-throwing method="throwing" pointcut-ref="zzz"></aop:after-throwing>
            <!-- 无论方法是否异常，都会加此逻辑 -->
            <aop:after-returning method="returning" pointcut-ref="zzz"></aop:after-returning>
            <!-- aop:around 是tcf模型
                包含：
                    方法之前、方法之后、方法异常时，方法最终(finally代码块)
            -->
            <aop:around method="around" pointcut-ref="zzz"></aop:around>
    </aop:aspect>
</aop:config>
<!-- 开启aop注解扫描 -->
<aop:aspectj-autoproxy></aop:aspectj-autoproxy>
```
