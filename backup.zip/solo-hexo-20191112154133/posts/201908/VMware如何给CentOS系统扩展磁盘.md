title: 【VMware】如何给CentOS系统扩展磁盘
date: '2019-08-17 13:55:18'
updated: '2019-08-17 14:04:39'
tags: [Linux]
permalink: /articles/2019/08/17/1566021318238.html
---

![timg.jpg](https://img.hacpai.com/file/2019/08/timg-a6677728.jpg)

有时候后我们在使用Vmware Workstation的虚拟机的时候，会发现磁盘突然不够用了。这个时候就需要进行磁盘扩展了。下面讲解一下如何操作。
# 扩展虚拟磁盘
## 查看磁盘空间
因为我用的CentOS系统没有可视化桌面，所以我们使用命令“df -hl”查看磁盘空间
剩余6.9G
![image.png](https://img.hacpai.com/file/2019/08/image-ca34568e.png)
## 关闭虚拟机。进入虚拟机设置。
注意只有关闭虚拟机才能扩展磁盘。
依次点击“硬件-磁盘-扩展”。
![image.png](https://img.hacpai.com/file/2019/08/image-dee3d3cf.png)

![image.png](https://img.hacpai.com/file/2019/08/image-12b15be9.png)

![image.png](https://img.hacpai.com/file/2019/08/image-8c1de325.png)
## 扩展对话框填写需要的容量（总容量）。
这里的扩展只完成了从客户机划分空间上的扩展，实际并未使用，也未扩展。
![image.png](https://img.hacpai.com/file/2019/08/image-56a3d2c5.png)
![image.png](https://img.hacpai.com/file/2019/08/image-419c7759.png)
# 分区、格式化
## 以下所有操作，务必在root账户下完成。
进入CentOS系统。终端“ls /dev”查看已存在的分区。
一般显示为sda*
![image.png](https://img.hacpai.com/file/2019/08/image-e893cba4.png)
## fdisk /dev/sda进入磁盘编辑。
这里具体选哪个看自己情况。一般Tab的自动填充就只能选一个。
进入fdisk，“m”可以查看帮助。
![image.png](https://img.hacpai.com/file/2019/08/image-eb753fc5.png)

## 输入“n”，添加新分区。
回车默认选择分区类型为主分区。
![image.png](https://img.hacpai.com/file/2019/08/image-c9c1065c.png)

![image.png](https://img.hacpai.com/file/2019/08/image-04044932.png)
## 分区号回车使用默认选择，记住分区号，之后容易找新创建的分区。
起始扇区和Last扇区回车默认即可。

![image.png](https://img.hacpai.com/file/2019/08/image-75ff8fab.png)

![image.png](https://img.hacpai.com/file/2019/08/image-31d5cea6.png)


## 输入“w”写分区表，写完之后会自动退出fdisk。
重启虚拟机，然后 “ls /dev/” 可以查看多出的分区，对应分区号。
![image.png](https://img.hacpai.com/file/2019/08/image-bfbdee0f.png)

![image.png](https://img.hacpai.com/file/2019/08/image-2652a5f4.png)

## “mkfs.ext2 /dev/sda3”格式化新分区。
![image.png](https://img.hacpai.com/file/2019/08/image-366848c4.png)

# 扩展
## 下面进入正式扩展。
“lvm”进入lvm（逻辑卷管理）管理。
“pvcreate /dev/sda3”为新分区创建物理卷。输入“y”擦除分区。
“pvdisplay”显示出新的物理卷。

![image.png](https://img.hacpai.com/file/2019/08/image-98ee5d64.png)

![image.png](https://img.hacpai.com/file/2019/08/image-1c8cabfa.png)

![image.png](https://img.hacpai.com/file/2019/08/image-df7ddd1d.png)

## “vgdisplay”显示卷分组，记下卷分组名字。
“vgextend centos /dev/sda3”把新建的物理卷添加到卷分组。
“vgdisplay”再次查看卷分组，分组大小已经改变。

![image.png](https://img.hacpai.com/file/2019/08/image-9fd96ddc.png)

![image.png](https://img.hacpai.com/file/2019/08/image-fe7b516a.png)

![image.png](https://img.hacpai.com/file/2019/08/image-ccb1eac0.png)

## 我们的目的是扩展逻辑卷。
“lvdisplay”查看并记下原有逻辑卷的路径。
“lvextend -L +9.99G /dev/centos/root”增加大小。图中有解释。
增加完成后，“exit”退出lvm。
![image.png](https://img.hacpai.com/file/2019/08/image-a653339e.png)

![image.png](https://img.hacpai.com/file/2019/08/image-8c53002c.png)

![image.png](https://img.hacpai.com/file/2019/08/image-d0f2798a.png)

## “df -h”查看文件系统的大小没变。这个时候就需要同步文件系统了。
“df -T”先查看文件系统的类型。这里的类型是“xfs”。

![image.png](https://img.hacpai.com/file/2019/08/image-d2eb6bf0.png)

![image.png](https://img.hacpai.com/file/2019/08/image-2552a360.png)

## “xfs_growfs /dev/centos/root”同步文件系统。
同步完成后使用 “df -h” 命令，可以看到大小已经改变。
至此，CentOS系统扩展磁盘成功。
![image.png](https://img.hacpai.com/file/2019/08/image-ad95693b.png)

![image.png](https://img.hacpai.com/file/2019/08/image-304fad3a.png)








